INSERT INTO tb_pessoa(nome, telefone, email) VALUES ('Guilherme Silverio', '6299999999','gg@gmail.com');

INSERT INTO tb_animal(nome, idade, animal, vacinado, castrado,pessoa_id) VALUES ('Rex', 1, 'Cachorro', true, true,1);

INSERT INTO tb_endereco(rua, numero, bairro, ponte_de_referencia,pessoa_id) VALUES ('Rua MG16', 'sn', 'Madre Germana', 'Proximo ao posto de saude', 1);

