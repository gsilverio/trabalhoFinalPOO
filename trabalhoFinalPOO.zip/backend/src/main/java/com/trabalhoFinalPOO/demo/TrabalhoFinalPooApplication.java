package com.trabalhoFinalPOO.demo;

import com.trabalhoFinalPOO.demo.entities.Endereco;
import com.trabalhoFinalPOO.demo.entities.Pessoa;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabalhoFinalPooApplication {

	public static void main(String[] args) {


		SpringApplication.run(TrabalhoFinalPooApplication.class, args);
	}

}
