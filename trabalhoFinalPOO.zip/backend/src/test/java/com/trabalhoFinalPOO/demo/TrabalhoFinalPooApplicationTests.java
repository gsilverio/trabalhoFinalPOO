package com.trabalhoFinalPOO.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabalhoFinalPooApplicationTests {

	@Test
	void contextLoads() {
	}

}
